# lex_empty.py
#
# No rules defined

import ply.lex as lex

tokens = [
    "PLUS",
    "MINUS",
    "NUMBER",
    ]



lex.lex()


